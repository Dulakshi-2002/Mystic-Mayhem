public class Army extends Character{
}
